export * from './home.module';
export * from './home.component';
