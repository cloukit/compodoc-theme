# List component

It display the lines of todos.
