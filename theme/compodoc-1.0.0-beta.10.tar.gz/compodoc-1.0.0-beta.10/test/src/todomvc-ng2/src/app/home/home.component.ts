import { Component } from '@angular/core';

/**
 * The home component
 */
@Component({
    selector: 'home',
    templateUrl: './home.component.html'
})
export class HomeComponent {

}
