import { Component } from '@angular/core';

/**
 * The compodoc component
 */
@Component({
    selector: 'compodoc',
    templateUrl: './compodoc.component.html'
})
export class CompodocComponent {

}
