import { Component } from '@angular/core';

/**
 * The todomvc component
 */
@Component({
    selector: 'todomvc',
    templateUrl: './todomvc.component.html'
})
export class TodoMVCComponent {

}
