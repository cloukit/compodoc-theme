# Introduction

This app is a simple todo list application

## Main features

- add a todo
- edit a todo
- delete a todo
- update status of a todo
- filter displayed todos
