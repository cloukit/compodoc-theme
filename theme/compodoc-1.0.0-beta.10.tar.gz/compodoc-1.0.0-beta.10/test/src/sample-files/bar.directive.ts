import { Directive } from '@angular/core';

@Directive({ selector: '[app-bar]' })
export class BarDirective { }