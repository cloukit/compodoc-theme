import { Directive } from '@angular2/core';

@Directive({ selector: '[app-foo]' })
export class FooDirective { }