export interface MiscellaneousData {
    variables;
    functions;
    enumerations;
    groupedVariables;
    groupedFunctions;
    groupedEnumerations;
}
