export interface ParsedData {
    modules;
    components;
    directives;
    injectables;
    interfaces;
    pipes;
    classes;
    miscellaneous;
    routesTree;
}
